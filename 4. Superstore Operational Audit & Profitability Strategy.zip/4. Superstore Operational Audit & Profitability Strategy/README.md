

# Superstore Operational Audit & Profitability Strategy

### Forensic Corporate Auditing & Visual Profit Optimization

## 📌 Project Overview

This project frames a high-stakes consulting engagement designed to rescue an enterprise-level "Superstore" from structural deficits and potential bankruptcy. By executing a deep-dive operational audit on historical multi-dimensional datasets, I isolated critical profit engines and systemic loss-makers, modeled a predictive advertising allocation framework, and delivered visual data evidence to reshape inventory and marketing strategy.

## 🛠 Technical Toolkit

* **Platform:** Tableau Desktop
* **Data Architecture:** Multi-table Left Joins (Orders $\rightarrow$ Returns)
* **Calculated Metrics:** Logical Binary Conversions (`IFNULL`, Type-casting)
* **Analytical Frameworks:** Return on Ad Spend (ROAS) Modeling, Seasonal Trend Analysis, Multi-Dimensional Matrix Profiling

## 🔍 Key Analytical Questions

1. **Profit Forensics:** Which nested dimensional pairs (e.g., Subcategory + Region) represent the most extreme profit centers and loss engines?
2. **Capital Allocation:** Which state-and-month combinations yield a high enough average profit per unit to justify targeted marketing investments?
3. **Deficit Diagnosis:** Do specific customer or product segments exhibit abnormally high product return rates that compromise overall profitability?

## 🚀 Workstream & Methodology

### 1. Relational Data Join & Logic Engineering

* **Table Architecture:** Executed a critical **LEFT JOIN** to connect the `Returns` table onto the primary `Orders` table, retaining all transactions while preserving sparse return indicators (`Yes` vs. `null`).
* **Field Engineering:** Created a custom calculated field transforming the string-based return field into a clean, binary numeric metric ($0$ for clean transactions, $1$ for returned orders). This allowed for the precise calculation of a continuous **Return Rate** metric across any business dimension.

### 2. Multi-Dimensional Profit Audit

* **Loss Isolation:** Cross-referenced overlapping dimensions (Subcategory + Region) to isolate massive operational leaks. Built visual justifications identifying the specific underperforming product lines and subcategories that the business must discontinue to avoid margin erosion.
* **Segment Profiling:** Mapped the average profit directly against the newly engineered return rate across geographic states and shipping modes, establishing an empirical boundary to separate viable business channels from toxic ones.

### 3. Predictive Advertising Model (ROAS)

* **Seasonal Filtering:** Evaluated profit trajectories across time and space to identify the top 3 high-yield combinations of geographic states and calendar months.
* **Capital Risk Modeling:** Implemented a conservative Return on Ad Spend baseline ($1/5\text{th}$ of projected profits allocated to marketing costs) to provide stakeholders with an exact ceiling for maximum customer acquisition costs (CAC).

## 💡 Strategic Insights

* **Inventory Pruning:** Outlined an executive recommendation to aggressively sunset three specific product subcategories that displayed a critical combination of low margins and high return frequency.
* **Targeted Capital Deployment:** Proved that marketing spend should not be distributed uniformly; instead, capital should be funneled exclusively into the 3 identified state/month clusters where unit profit margins comfortably absorb promotional overhead.

## 📂 Project Structure

* **Profits & Losses Dashboard:** Diagnostic cross-tabs and bar charts isolating segment performance.
* **Ad Spend Optimization Model:** Trend lines and matrix visuals defining the $20\%$ profit-reinvestment threshold.
* **Return Rate Matrix Sheet:** Scatterplots tracking the correlation between raw sales volume, profit margins, and customer return rates.

---

**Saurav Dahal**
*Business Intelligence Analyst | Data Engineer | Technical Liaison*
*📍 Dallas-Fort Worth (DFW), Texas*