# E-commerce Conversion & Cohort Analysis

### Customer Lifecycle Analytics & Event Log Modeling

## 📌 Project Overview

This project focuses on transforming raw, high-volume website transaction logs into structured business metrics. By building an end-to-end user lifecycle pipeline, I constructed a multi-stage **Conversion Funnel** to pinpoint customer drop-off bottlenecks and architected a monthly **Retention Cohort Matrix** to track customer loyalty and long-term user value over time.

## 🛠 Technical Toolkit

- **Languages & Querying:** SQL (Relational Filters, Event Isolation)
- **Platform:** Google Sheets / Excel
- **Key Functions:** `VLOOKUP()`, `DATEDIF()`, `TEXT()`
- **Methodology:** Cohort Analysis, Funnel Modeling, ETL/Data Isolation, Executive Reporting

## 🔍 Key Analytical Questions

1. **Funnel Efficiency:** How effectively does the e-commerce platform convert initial product page views into completed purchases?
2. **User Retention:** How does customer loyalty decay month-over-month when grouped by their initial acquisition month?
3. **Friction Points:** At which stage of the user journey (View vs. Cart) does the most significant customer drop-off occur?

## 🚀 Workstream & Methodology

### 1. Data Isolation & Preparation (ETL)

- **Event Partitioning:** Isolated purchase events from a master event log containing thousands of raw website interactions (Views, Cart Additions, Purchases).
- **Relational Mapping:** Built a secondary reference model to calculate the absolute minimum event timestamp per customer. Populated these values back into the primary activity sheet using a robust `VLOOKUP()` architecture to establish a definitive "First Purchase Date" for every user.

### 2. Time-Series Normalization

- **Date Dimension Engineering:** Utilized the `TEXT()` function to convert granular dates into standardized `YYYY-MM` periods for both transaction and acquisition months.
- **Cohort Age Calculation:** Applied the `DATEDIF()` function to calculate the precise index gap (Months 0 to 4) between a customer's first purchase and any subsequent transaction, establishing a normalized baseline for all user cohorts.

### 3. Funnel & Cohort Modeling

- **Conversion Funnel:** Built a 3-stage pivot table funnel (Product Page View $\rightarrow$ Shopping Cart $\rightarrow$ Completed Purchase) evaluating unique user counts, total conversion rates, and step-to-step drop-off ratios.
- **Retention Matrix:** Aggregated raw data into 6 distinct monthly acquisition cohorts. Built a dedicated retention matrix using absolute column references to track user return percentages over a rolling 4-month lifecycle.

## 💡 Strategic Insights

- **Funnel Bottlenecks:** Pinpointed the exact conversion stage responsible for the highest cart-abandonment rate, providing a clear optimization target for the UX/UI product development teams.
- **Cohort Decay:** Provided executive leadership with a clear view of customer decay curves, establishing an empirical baseline to measure the lifetime value (LTV) of newly acquired user groups.

## 📂 Project Structure

- **Executive Summary & Synopsis:** High-level strategic results and underlying data assumptions for C-suite review.
- **Conversion Funnel Sheet:** Step-by-step conversion analytics and pivot models.
- **Cohort & Retention Sheet:** Cleaned purchase records, cohort age calculations, and the final percentage-based retention matrix.

---

**Saurav Dahal**
_Business Intelligence Analyst | Data Engineer | Technical Liaison_
_📍 Dallas-Fort Worth (DFW), Texas_
