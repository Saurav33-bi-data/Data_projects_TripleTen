README: Superstore Returns Root Cause Analysis
Tableau public: https://public.tableau.com/app/profile/saurav.dahal/viz/SauravDahalStorytellingwithDataProject/Mockupdashboard1?publish=yes

Project Overview
This project provides a comprehensive analysis of return rates for the Superstore. It identifies geographic and seasonal drivers of returns and provides an interactive dashboard for executive monitoring.

1. Files Included in this Submission
Mockups_Sketches.pdf: Three low-fidelity pen-and-paper variations of the dashboard design.

Dashboard_Template.png: A screenshot of the Tableau "Gray Box" container layout, demonstrating a structured design process.

Superstore_Analysis.twbx: The final packaged Tableau workbook containing all worksheets, the finalized dashboard, and the Story Arc.

Executive_Presentation.mp4 (or PDF): A 4-minute recorded walkthrough of the data findings and strategic recommendations.

2. Dashboard Features & Navigation
Geographic Map: Use this to filter the entire dashboard by State or Region.

Seasonal Line Chart: Highlights the "August/September Tech Spike." Hover over data points for specific return percentages.

Executive Action Plan: A dedicated sidebar with data-backed business recommendations for the CEO.

10px Gutters: All objects are separated by 10px blank spacers for a clean, professional aesthetic.

3. Key Analytical Findings (Salient Features)
Return Rate vs. Volume: This analysis prioritizes Return Rate to identify quality failures, while Total Returns are used to assess logistics costs.

The West Region Crisis: The Western region shows a significantly higher return rate than national averages, specifically in Office Supplies.

Seasonal Risk: Technology returns peak annually during the "Back to School" window, suggesting a mismatch between marketing and product expectations.

4. Instructions for Review
Open the .twbx file in Tableau Desktop or Tableau Public.

Navigate to the tab labeled "Presentation Story".

Use Presentation Mode (F7) to view the story points in full screen.

Interact with the Map on Slide 4 to see the dynamic filtering in action.


📂 Project Structure Update (Instructor Feedback Applied)
Following the project evaluation, all individual worksheets and dashboards have been consolidated into one cohesive Tableau Story with multiple Story Points. This ensures a logical, narrative-driven flow from data ingestion to final executive recommendations.

🗺️ Tableau Story Navigation
Navigate to the tab labeled "Final Executive Presentation" to view the structured story points:

Story Point 1 – Executive Summary & Metric Definition: Overview of the business context and definition of Return Rate (calculated as AVG(Returned Flag) where Yes = 1 and Null = 0).

Story Point 2 – Root Causes (Correlation & Geography): Scatterplot and map views demonstrating regional return concentrations.

Story Point 3 – Root Causes (Seasonal Trends): Time-based analysis isolating the August/September technology spikes.

Story Point 4 – Returns Dashboard (Monitoring Tool): High-level overview of the unified interactive dashboard.

Story Point 5 – Interactive Demonstration (West Region Deep Dive): A live snapshot proving dashboard interactivity by filtering data specifically to the Western Logistics profile.

Story Point 6 – Conclusions & Strategic Next Steps: Summary of findings and a 30/60/90-day action plan for the CEO.

⚙️ Left Join & Data Preparation Verified
Orders & Returns Tables: Successfully combined using a standard LEFT JOIN.

Returned Flag Formula: Verified data cleanliness displaying accurate Yes and null distributions before calculating rates.