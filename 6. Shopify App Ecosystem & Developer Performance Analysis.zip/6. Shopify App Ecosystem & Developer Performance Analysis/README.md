# Shopify App Ecosystem & Developer Performance Analysis

### Advanced Relational Data Modeling & DAX Metrics Engineering

## 📌 Project Overview

This project focuses on evaluating market indicators that determine software success within a major digital marketplace. Utilizing public data scraped from the Shopify App Store, I engineered an end-to-end Power BI reporting ecosystem. The analysis connects core application profiles with multi-tier user reviews to identify key success correlations and benchmark developer responsiveness at scale.

## 🛠 Technical Toolkit

* **Platform:** Power BI Desktop
* **Data Modeling:** Star Schema / Many-to-One (`1:*`) Relational Mapping
* **Data Analysis Expressions (DAX):** Custom Calculated Columns, Conditional Logic, Weighted Aggregations
* **Visualizations:** KPI Summaries, Trend Line Charts, Multi-Dimensional Scatterplots, Filtered Performance Scorecards

## 🔍 Key Analytical Questions

1. **Marketplace Trends:** What is the overarching landscape of the app marketplace, and how do update frequencies correlate with overall user sentiment?
2. **Review Validation:** How can user reviews be mathematically weighted to filter out low-validity or misleading feedback?
3. **Operational Responsiveness:** Which application developers are the most engaged and responsive to customer feedback, and does this directly affect their rating thresholds?

## 🚀 Workstream & Methodology

### 1. Relational Data Architecture

* **Data Schema Design:** Modeled a clean relational data schema by establishing a **Many-to-One (`Many:*`) relationship** between the high-volume `Reviews` table (`app_id`) and the primary `Apps` dimension table (`id`).
* **Granular Filtering:** Integrated connecting tables (`apps_categories`, `categories`) to enable seamless cross-table filtering, ensuring "one version of the truth" across multi-page dashboard layouts.

### 2. Advanced DAX Engineering

* **Feedback Weighting:** Authored a custom DAX calculated column named `helpful_reviews` to scale user ratings based on community validation, preventing skewed data from unverified reviews:

$$\text{helpful\_reviews} = \text{rating} \times (1 + \text{helpful\_count})$$


* **Engagement Logic:** Developed a conditional DAX column named `developer_answered` to parse string fields and flag developer activity, assigning a binary $1$ (TRUE) if a `developer_reply` was present and a $0$ (FALSE) if the field row was blank.

### 3. Diagnostic Visualizations & Forensics

* **App Landscape Tracking:** Deployed high-level **KPI Cards** to display unique app counts and built continuous **Line Charts** on raw modified dates (`lastmod`) to track developer maintenance cycles over time.
* **Metric Validation Audit:** Identified a key analytical risk where a basic "Sum of Ratings" generated a highly misleading bar chart (inflated by volume rather than quality). Re-engineered the core visual to map developers against the **Helpful Review Average** to restore analytical integrity.
* **Responsiveness Benchmarking:** Isolated top-tier marketplace players by constructing a developer performance bar chart, applying a specific visual filter to exclude low-volume outliers and target only apps with a `reviews_count > 500`.

## 💡 Strategic Insights

* **The Engagement Premium:** Proved via scatterplot analysis that individual reviews receiving a developer response maintain a statistically distinct alignment with higher ratings compared to unanswered feedback.
* **Platform Health Baseline:** Established clear performance scorecards for third-party software developers, offering an empirical benchmark for application success factors within the e-commerce ecosystem.

## 📂 Project Structure

* **App Landscape Panel:** High-level ecosystem statistics, update frequencies, and volume scatterplots.
* **Reviews Audit Sheet:** DAX calculated metrics tracking community-weighted feedback and overall response indicators.
* **App Reviews Dashboard:** Filtered developer benchmark charts isolating high-volume marketplace leaders.

---

**Saurav Dahal**
*Business Intelligence Analyst | Data Engineer | Technical Liaison*
*📍 Dallas-Fort Worth (DFW), Texas*