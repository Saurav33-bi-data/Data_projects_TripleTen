
# Manhattan Airbnb Investment Analysis

### Strategic Market Study & Revenue Modeling

## 📌 Project Overview

This project serves as a comprehensive market analysis for a client looking to invest in the Manhattan vacation rental market. Using raw Airbnb datasets, I conducted an end-to-end analysis to identify high-ROI property types and locations, providing a data-driven roadmap for real estate investment.

## 🛠 Technical Toolkit

* **Platform:** Google Sheets / Excel
* **Functions:** `SUMIF()`, `IF()`, `VLOOKUP()`, and advanced string manipulation.
* **Visualizations:** Pivot Tables, Bar Charts, and Dynamic Dashboards.
* **Methodology:** Data Cleaning (Change Logs), Revenue Modeling, and Executive Reporting.

## 🔍 Key Analytical Questions

1. **Market Attractiveness:** Which neighborhoods and property sizes (number of bedrooms) see the highest rental frequency?
2. **Revenue Generation:** How much annual revenue do these top-performing listings generate?
3. **Investment Optimization:** Do different neighborhoods have different preferences for property sizes?

## 🚀 Workstream & Methodology

### 1. Data Cleaning & Integrity

* **Standardization:** Cleaned neighborhood column labels to remove inconsistent capitalization and trailing spaces into a new `neighborhood_clean` field to ensure accurate grouping.
* **Handling Nulls:** Utilized the `IF` function to categorize empty bedroom cells as **Studio Apartments**, preventing data loss during aggregation.
* **Documentation:** Maintained a professional **Change Log** to document every cleaning step for stakeholder transparency.

### 2. Forensic Market Analysis

* **Attractiveness Scoring:** Used `number_of_reviews_ltm` (reviews in the last 12 months) as a proxy for rental frequency to rank the Top 10 neighborhoods.
* **Granular Insights:** Built multi-layered Pivot Tables to determine that while 1-bedroom apartments are the most popular generally, **Studios are the optimal investment in Midtown**.

### 3. Financial Modeling

* **Daily Revenue Mapping:** Created a `revenue_earned` column in the calendar data, using conditional logic to map `adjusted_price` to specific rental dates only when the property was occupied (`available = "f"`).
* **Annual Projections:** Calculated 30-day totals using `SUMIF` and extrapolated annual revenue estimates to rank listings by potential ROI ($30\text{-day total} \times 12$).

## 💡 Strategic Insights

* **Top Neighborhoods:** Identified the top-earning listings in Manhattan, with the leading property generating approximately **$29,940 in a single 30-day period**.
* **Optimal Sizing:** Recommended a shift toward **1-bedroom units** across the top 10 neighborhoods, with a targeted exception for **Studios in high-traffic commercial hubs** like Midtown to maximize occupancy and revenue.

## 📂 Project Structure

* **Executive Summary:** High-level recommendations and analysis assumptions.
* **Analysis Sheets:** Pivot Tables and Charts organized by neighborhood and bedroom count.
* **Data Audit:** Detailed documentation of cleaning steps and data assumptions.

---

**Saurav Dahal**
*Business Intelligence Analyst | Data Engineer | Technical Liaison*
*📍 Dallas-Fort Worth (DFW), Texas*